# Cue run statistics (strict premise rule)

319277 grades of 82198 answers, 162 questions, 5 judges.

## judge agreement

| judge_a | judge_b | answers | pearson | spearman | mean_difference | hard_fail_kappa |
|---|---|---|---|---|---|---|
| gemma-4-31b-it | gpt-oss-120b | 41712 | 0.705 | 0.647 | 1.492 | 0.360 |
| gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 50703 | 0.475 | 0.499 | -1.186 | -0.000 |
| gemma-4-31b-it | olmo-3.1-32b-instruct | 47683 | 0.379 | 0.355 | 0.551 | 0.194 |
| gemma-4-31b-it | qwen3.8-27b | 41371 | 0.737 | 0.648 | 2.928 | 0.533 |
| gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 63381 | 0.536 | 0.561 | -2.831 | 0.001 |
| gpt-oss-120b | olmo-3.1-32b-instruct | 62234 | 0.497 | 0.505 | -1.019 | 0.244 |
| gpt-oss-120b | qwen3.8-27b | 36528 | 0.698 | 0.620 | 1.554 | 0.251 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 76747 | 0.424 | 0.500 | 1.849 | 0.002 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 44300 | 0.432 | 0.420 | 4.421 | 0.000 |
| olmo-3.1-32b-instruct | qwen3.8-27b | 41395 | 0.461 | 0.469 | 2.679 | 0.123 |

## panel alpha

| measure | krippendorff_alpha |
|---|---|
| total | 0.361 |
| accuracy | 0.276 |
| completeness | 0.520 |
| context | 0.393 |
| evidence | 0.105 |
| reasoning | 0.248 |
| framing | 0.134 |

## criteria

| criterion | accuracy | completeness | context | evidence | reasoning | framing | total |
|---|---|---|---|---|---|---|---|
| accuracy | 1.000 | 0.386 | 0.535 | 0.388 | 0.674 | 0.384 | 0.615 |
| completeness | 0.386 | 1.000 | 0.601 | 0.425 | 0.538 | 0.244 | 0.771 |
| context | 0.535 | 0.601 | 1.000 | 0.478 | 0.677 | 0.299 | 0.784 |
| evidence | 0.388 | 0.425 | 0.478 | 1.000 | 0.437 | 0.222 | 0.787 |
| reasoning | 0.674 | 0.538 | 0.677 | 0.437 | 1.000 | 0.350 | 0.738 |
| framing | 0.384 | 0.244 | 0.299 | 0.222 | 0.350 | 1.000 | 0.312 |
| total | 0.615 | 0.771 | 0.784 | 0.787 | 0.738 | 0.312 | 1.000 |

## length

| by | level | grades | spearman_words_total | pearson_within_question |
|---|---|---|---|---|
| judge | all | 319277 | 0.172 | 0.173 |
| judge | gemma-4-31b-it | 51317 | 0.254 | 0.224 |
| judge | gpt-oss-120b | 64319 | 0.260 | 0.301 |
| judge | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 80743 | 0.406 | 0.335 |
| judge | olmo-3.1-32b-instruct | 77953 | 0.074 | 0.076 |
| judge | qwen3.8-27b | 44945 | -0.006 | 0.053 |
| provider | gemma-4-31b-it | 62579 | 0.101 | 0.123 |
| provider | gpt-oss-120b | 64674 | 0.173 | 0.297 |
| provider | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 63955 | 0.014 | 0.096 |
| provider | olmo-3.1-32b-instruct | 64790 | 0.136 | 0.127 |
| provider | qwen3.8-27b | 63279 | 0.016 | 0.101 |

## by group

| group | answers | score | score_minus_baseline | words | words_minus_baseline | addresses_asker | majority_hard_fail | hard_fail_ci_low | hard_fail_ci_high |
|---|---|---|---|---|---|---|---|---|---|
| did not finish high school | 9394 | 20.200 | -0.460 | 416.218 | -104.658 | 0.429 | 0.012 | 0.010 | 0.014 |
| irrelevant | 4703 | 20.273 | -0.387 | 403.912 | -116.964 | 0.350 | 0.016 | 0.013 | 0.020 |
| White woman | 14082 | 20.582 | -0.078 | 443.263 | -77.613 | 0.349 | 0.017 | 0.015 | 0.019 |
| Black woman | 14112 | 20.599 | -0.061 | 460.252 | -60.624 | 0.385 | 0.016 | 0.014 | 0.018 |
| White man | 14066 | 20.614 | -0.046 | 456.086 | -64.790 | 0.334 | 0.015 | 0.014 | 0.018 |
| Black man | 14080 | 20.618 | -0.042 | 462.376 | -58.500 | 0.376 | 0.017 | 0.015 | 0.019 |
| doctorate | 9424 | 20.637 | -0.024 | 537.647 | 16.771 | 0.383 | 0.018 | 0.016 | 0.021 |
| baseline | 2337 | 20.660 | 0.000 | 520.876 | 0.000 | 0.219 | 0.016 | 0.012 | 0.022 |

## model correlation

| model_a | model_b | questions | pearson | ci_low | ci_high | spearman |
|---|---|---|---|---|---|---|
| gemma-4-31b-it | gpt-oss-120b | 161 | 0.478 | 0.349 | 0.589 | 0.700 |
| gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 161 | 0.697 | 0.607 | 0.768 | 0.721 |
| gemma-4-31b-it | olmo-3.1-32b-instruct | 161 | 0.710 | 0.623 | 0.779 | 0.785 |
| gemma-4-31b-it | qwen3.8-27b | 161 | 0.873 | 0.831 | 0.905 | 0.880 |
| gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | 0.632 | 0.529 | 0.716 | 0.753 |
| gpt-oss-120b | olmo-3.1-32b-instruct | 162 | 0.716 | 0.631 | 0.783 | 0.747 |
| gpt-oss-120b | qwen3.8-27b | 162 | 0.522 | 0.400 | 0.626 | 0.722 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 162 | 0.848 | 0.798 | 0.886 | 0.816 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 162 | 0.731 | 0.650 | 0.796 | 0.771 |
| olmo-3.1-32b-instruct | qwen3.8-27b | 162 | 0.725 | 0.642 | 0.791 | 0.805 |

## test retest

| run_a | run_b | question_model_pairs | pearson | ci_low | ci_high | mean_abs_difference |
|---|---|---|---|---|---|---|
| 0 | 1 | 771 | 0.831 | 0.808 | 0.852 | 0.949 |
| 0 | 2 | 770 | 0.791 | 0.763 | 0.816 | 0.964 |
| 1 | 2 | 773 | 0.809 | 0.783 | 0.832 | 0.961 |

## gap by question

| gap | questions | mean | sd | share_negative | min | max | corr_with_baseline_score | ci_low | ci_high |
|---|---|---|---|---|---|---|---|---|---|
| education | 162 | -0.426 | 0.531 | 0.858 | -1.579 | 2.039 | -0.157 | -0.304 | -0.003 |
| race | 162 | 0.044 | 0.244 | 0.469 | -0.581 | 1.899 | -0.078 | -0.229 | 0.078 |

## gap between models

| gap | model_a | model_b | questions | pearson | ci_low | ci_high |
|---|---|---|---|---|---|---|
| education | gemma-4-31b-it | gpt-oss-120b | 153 | 0.421 | 0.281 | 0.543 |
| education | gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 153 | 0.024 | -0.135 | 0.182 |
| education | gemma-4-31b-it | olmo-3.1-32b-instruct | 153 | 0.231 | 0.075 | 0.376 |
| education | gemma-4-31b-it | qwen3.8-27b | 153 | 0.508 | 0.380 | 0.617 |
| education | gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 160 | 0.154 | -0.001 | 0.302 |
| education | gpt-oss-120b | olmo-3.1-32b-instruct | 162 | 0.324 | 0.179 | 0.456 |
| education | gpt-oss-120b | qwen3.8-27b | 161 | 0.282 | 0.134 | 0.419 |
| education | llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 160 | 0.105 | -0.050 | 0.256 |
| education | llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 159 | -0.051 | -0.205 | 0.106 |
| education | olmo-3.1-32b-instruct | qwen3.8-27b | 161 | 0.029 | -0.126 | 0.183 |
| race | gemma-4-31b-it | gpt-oss-120b | 157 | -0.063 | -0.217 | 0.095 |
| race | gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 157 | 0.005 | -0.151 | 0.162 |
| race | gemma-4-31b-it | olmo-3.1-32b-instruct | 157 | -0.077 | -0.231 | 0.080 |
| race | gemma-4-31b-it | qwen3.8-27b | 156 | 0.579 | 0.464 | 0.675 |
| race | gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | -0.042 | -0.195 | 0.112 |
| race | gpt-oss-120b | olmo-3.1-32b-instruct | 162 | -0.032 | -0.185 | 0.123 |
| race | gpt-oss-120b | qwen3.8-27b | 160 | -0.089 | -0.240 | 0.067 |
| race | llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 162 | -0.236 | -0.377 | -0.085 |
| race | llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 160 | 0.150 | -0.005 | 0.298 |
| race | olmo-3.1-32b-instruct | qwen3.8-27b | 160 | 0.007 | -0.149 | 0.162 |

