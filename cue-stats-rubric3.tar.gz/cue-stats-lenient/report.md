# Cue run statistics (lenient premise rule)

410696 grades of 85050 answers, 162 questions, 5 judges.

## judge agreement

| judge_a | judge_b | answers | pearson | spearman | mean_difference | hard_fail_kappa |
|---|---|---|---|---|---|---|
| gemma-4-31b-it | gpt-oss-120b | 77254 | 0.687 | 0.647 | 1.730 | 0.329 |
| gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 84061 | 0.473 | 0.500 | -1.330 | 0.009 |
| gemma-4-31b-it | olmo-3.1-32b-instruct | 81188 | 0.412 | 0.384 | 0.659 | 0.169 |
| gemma-4-31b-it | qwen3.8-27b | 82744 | 0.725 | 0.651 | 2.930 | 0.544 |
| gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 76537 | 0.605 | 0.596 | -3.052 | 0.003 |
| gpt-oss-120b | olmo-3.1-32b-instruct | 75490 | 0.572 | 0.548 | -1.043 | 0.189 |
| gpt-oss-120b | qwen3.8-27b | 75544 | 0.697 | 0.629 | 1.135 | 0.263 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 80531 | 0.527 | 0.538 | 2.018 | 0.001 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 82021 | 0.454 | 0.430 | 4.267 | 0.002 |
| olmo-3.1-32b-instruct | qwen3.8-27b | 79254 | 0.513 | 0.487 | 2.248 | 0.121 |

## panel alpha

| measure | krippendorff_alpha |
|---|---|
| total | 0.435 |
| accuracy | 0.324 |
| completeness | 0.576 |
| context | 0.464 |
| evidence | 0.190 |
| reasoning | 0.281 |
| framing | 0.125 |

## criteria

| criterion | accuracy | completeness | context | evidence | reasoning | framing | total |
|---|---|---|---|---|---|---|---|
| accuracy | 1.000 | 0.419 | 0.555 | 0.436 | 0.680 | 0.348 | 0.661 |
| completeness | 0.419 | 1.000 | 0.649 | 0.460 | 0.561 | 0.227 | 0.786 |
| context | 0.555 | 0.649 | 1.000 | 0.530 | 0.697 | 0.279 | 0.821 |
| evidence | 0.436 | 0.460 | 0.530 | 1.000 | 0.476 | 0.205 | 0.795 |
| reasoning | 0.680 | 0.561 | 0.697 | 0.476 | 1.000 | 0.333 | 0.771 |
| framing | 0.348 | 0.227 | 0.279 | 0.205 | 0.333 | 1.000 | 0.316 |
| total | 0.661 | 0.786 | 0.821 | 0.795 | 0.771 | 0.316 | 1.000 |

## length

| by | level | grades | spearman_words_total | pearson_within_question |
|---|---|---|---|---|
| judge | all | 410696 | 0.198 | 0.163 |
| judge | gemma-4-31b-it | 84917 | 0.261 | 0.155 |
| judge | gpt-oss-120b | 77387 | 0.289 | 0.289 |
| judge | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 84194 | 0.421 | 0.327 |
| judge | olmo-3.1-32b-instruct | 81321 | 0.117 | 0.116 |
| judge | qwen3.8-27b | 82877 | 0.031 | 0.047 |
| provider | gemma-4-31b-it | 82577 | 0.180 | 0.133 |
| provider | gpt-oss-120b | 79170 | 0.171 | 0.265 |
| provider | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 83150 | 0.054 | 0.098 |
| provider | olmo-3.1-32b-instruct | 82942 | 0.146 | 0.142 |
| provider | qwen3.8-27b | 82857 | 0.140 | 0.146 |

## by group

| group | answers | score | score_minus_baseline | words | words_minus_baseline | addresses_asker | majority_hard_fail | hard_fail_ci_low | hard_fail_ci_high |
|---|---|---|---|---|---|---|---|---|---|
| did not finish high school | 9720 | 19.757 | -0.500 | 410.093 | -100.471 | 0.440 | 0.017 | 0.015 | 0.020 |
| irrelevant | 4860 | 19.856 | -0.401 | 397.785 | -112.779 | 0.362 | 0.020 | 0.017 | 0.025 |
| White woman | 14580 | 20.064 | -0.194 | 436.245 | -74.319 | 0.364 | 0.023 | 0.021 | 0.026 |
| Black woman | 14580 | 20.071 | -0.186 | 453.180 | -57.383 | 0.399 | 0.024 | 0.021 | 0.026 |
| Black man | 14580 | 20.094 | -0.163 | 454.667 | -55.896 | 0.391 | 0.023 | 0.020 | 0.025 |
| White man | 14580 | 20.103 | -0.154 | 448.034 | -62.530 | 0.350 | 0.023 | 0.021 | 0.026 |
| baseline | 2430 | 20.257 | 0.000 | 510.564 | 0.000 | 0.238 | 0.021 | 0.016 | 0.027 |
| doctorate | 9720 | 20.264 | 0.007 | 530.295 | 19.731 | 0.396 | 0.025 | 0.022 | 0.029 |

## model correlation

| model_a | model_b | questions | pearson | ci_low | ci_high | spearman |
|---|---|---|---|---|---|---|
| gemma-4-31b-it | gpt-oss-120b | 162 | 0.692 | 0.602 | 0.765 | 0.746 |
| gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | 0.790 | 0.724 | 0.842 | 0.757 |
| gemma-4-31b-it | olmo-3.1-32b-instruct | 162 | 0.817 | 0.758 | 0.862 | 0.840 |
| gemma-4-31b-it | qwen3.8-27b | 162 | 0.929 | 0.904 | 0.947 | 0.886 |
| gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | 0.686 | 0.595 | 0.760 | 0.738 |
| gpt-oss-120b | olmo-3.1-32b-instruct | 162 | 0.776 | 0.706 | 0.831 | 0.740 |
| gpt-oss-120b | qwen3.8-27b | 162 | 0.690 | 0.599 | 0.763 | 0.753 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 162 | 0.845 | 0.795 | 0.884 | 0.799 |
| llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 162 | 0.792 | 0.726 | 0.843 | 0.799 |
| olmo-3.1-32b-instruct | qwen3.8-27b | 162 | 0.823 | 0.765 | 0.867 | 0.860 |

## test retest

| run_a | run_b | question_model_pairs | pearson | ci_low | ci_high | mean_abs_difference |
|---|---|---|---|---|---|---|
| 0 | 1 | 810 | 0.887 | 0.871 | 0.901 | 0.898 |
| 0 | 2 | 810 | 0.857 | 0.838 | 0.874 | 0.919 |
| 1 | 2 | 810 | 0.863 | 0.845 | 0.880 | 0.925 |

## gap by question

| gap | questions | mean | sd | share_negative | min | max | corr_with_baseline_score | ci_low | ci_high |
|---|---|---|---|---|---|---|---|---|---|
| education | 162 | -0.507 | 0.442 | 0.889 | -1.838 | 1.074 | -0.161 | -0.307 | -0.007 |
| race | 162 | -0.001 | 0.154 | 0.543 | -0.432 | 0.600 | 0.124 | -0.031 | 0.273 |

## gap between models

| gap | model_a | model_b | questions | pearson | ci_low | ci_high |
|---|---|---|---|---|---|---|
| education | gemma-4-31b-it | gpt-oss-120b | 162 | 0.358 | 0.216 | 0.485 |
| education | gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | 0.205 | 0.052 | 0.348 |
| education | gemma-4-31b-it | olmo-3.1-32b-instruct | 162 | 0.297 | 0.150 | 0.432 |
| education | gemma-4-31b-it | qwen3.8-27b | 162 | 0.387 | 0.247 | 0.510 |
| education | gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | 0.160 | 0.006 | 0.306 |
| education | gpt-oss-120b | olmo-3.1-32b-instruct | 162 | 0.317 | 0.172 | 0.450 |
| education | gpt-oss-120b | qwen3.8-27b | 162 | 0.275 | 0.126 | 0.412 |
| education | llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 162 | 0.063 | -0.093 | 0.215 |
| education | llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 162 | 0.166 | 0.012 | 0.312 |
| education | olmo-3.1-32b-instruct | qwen3.8-27b | 162 | 0.167 | 0.013 | 0.313 |
| race | gemma-4-31b-it | gpt-oss-120b | 162 | 0.066 | -0.089 | 0.218 |
| race | gemma-4-31b-it | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | 0.198 | 0.045 | 0.341 |
| race | gemma-4-31b-it | olmo-3.1-32b-instruct | 162 | -0.035 | -0.189 | 0.119 |
| race | gemma-4-31b-it | qwen3.8-27b | 162 | -0.002 | -0.156 | 0.152 |
| race | gpt-oss-120b | llama-4-scout-17b-16e-instruct-quantized.w4a16 | 162 | 0.094 | -0.061 | 0.245 |
| race | gpt-oss-120b | olmo-3.1-32b-instruct | 162 | 0.044 | -0.111 | 0.197 |
| race | gpt-oss-120b | qwen3.8-27b | 162 | -0.052 | -0.205 | 0.103 |
| race | llama-4-scout-17b-16e-instruct-quantized.w4a16 | olmo-3.1-32b-instruct | 162 | 0.128 | -0.026 | 0.277 |
| race | llama-4-scout-17b-16e-instruct-quantized.w4a16 | qwen3.8-27b | 162 | 0.215 | 0.063 | 0.357 |
| race | olmo-3.1-32b-instruct | qwen3.8-27b | 162 | 0.003 | -0.151 | 0.157 |

